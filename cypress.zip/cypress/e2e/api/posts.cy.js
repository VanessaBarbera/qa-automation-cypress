describe('API - JSONPlaceholder', () => {
  const apiUrl = 'https://jsonplaceholder.typicode.com';

  it('deve consultar um post com sucesso', () => {
    cy.request('GET', `${apiUrl}/posts/1`).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.have.property('id', 1);
      expect(response.body).to.have.property('title');
      expect(response.body).to.have.property('body');
    });
  });

  it('deve criar um post e validar a resposta', () => {
    const payload = {
      title: 'Automação de testes com Cypress',
      body: 'Teste de API criado para portfólio de Quality Assurance',
      userId: 1,
    };

    cy.request('POST', `${apiUrl}/posts`, payload).then((response) => {
      expect(response.status).to.eq(201);
      expect(response.body).to.include(payload);
      expect(response.body).to.have.property('id');
    });
  });
});
