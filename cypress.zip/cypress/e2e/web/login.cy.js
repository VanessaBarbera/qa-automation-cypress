const loginPage = require('../../pages/LoginPage');
const inventoryPage = require('../../pages/InventoryPage');

describe('Login - SauceDemo', () => {
  beforeEach(() => {
    cy.fixture('users').as('users');
    loginPage.visit();
  });

  it('deve realizar login com credenciais válidas', function () {
    loginPage.login(
      this.users.validUser.username,
      this.users.validUser.password
    );

    cy.url().should('include', '/inventory.html');
    inventoryPage.getTitle().should('have.text', 'Products');
    inventoryPage.getInventoryItems().should('have.length.greaterThan', 0);
  });

  it('deve exibir mensagem de erro para senha inválida', function () {
    loginPage.login(
      this.users.invalidUser.username,
      this.users.invalidUser.password
    );

    loginPage
      .getErrorMessage()
      .should('be.visible')
      .and('contain.text', 'Username and password do not match');
  });
});
