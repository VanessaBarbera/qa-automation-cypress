const loginPage = require('../../pages/LoginPage');
const inventoryPage = require('../../pages/InventoryPage');

describe('Carrinho - SauceDemo', () => {
  beforeEach(() => {
    cy.fixture('users').then((users) => {
      loginPage.visit();
      loginPage.login(users.validUser.username, users.validUser.password);
    });
  });

  it('deve adicionar um produto ao carrinho', () => {
    inventoryPage.addFirstProductToCart();

    inventoryPage
      .getCartBadge()
      .should('be.visible')
      .and('have.text', '1');
  });
});
